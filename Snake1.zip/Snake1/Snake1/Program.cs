﻿using System;
using Snake1.Class;

namespace Snake1
{
    class Program
    {
        static void Main(string[] args)
        {
            GameManager gameManager = new GameManager();
            gameManager.Run();
        }
    }
}
